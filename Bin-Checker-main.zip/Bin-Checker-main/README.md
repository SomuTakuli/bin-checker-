# Bin-Checker-Bot

A simple Telegram bot, in PHP, to check if the bin is valid or not.

# DEPLOY
YOU CAN SIMPLY DEPLOY ON HEROKU BY CLICKING THE BUTTON BELOW

[![Deploy To Heroku](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/deploy?template=https://github.com/Benchamxd/Bin-Checker/tree/main)

AFTER DEPLOY DO SET WEBHOOK BY ``api.telegram.org/bot<your bot token>/setwebhook?url=<Heroku site link>/bot.php``

# Configarations

``BOT_TOKEN : YOUR BOT TOKEN FROM @BOTFATHER``

``START_MESSAGE : A START MESSAGE FOR YOUR BOT``

# COMMANDS

``/start - To stat the bin``

``/bin xxxxx - To Check the bin``

## HELP ME

For any type of help on deploy. Contact us on [INDUS CHATS](https://t.me/induschats).


##

**DO GIVE A STAR TO MY PROJECT TO SHOW YOUR SUPPORT!!**
